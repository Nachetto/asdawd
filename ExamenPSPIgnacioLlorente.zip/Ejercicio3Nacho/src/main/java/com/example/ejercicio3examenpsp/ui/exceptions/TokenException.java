package com.example.ejercicio3examenpsp.ui.exceptions;

public class TokenException extends RuntimeException{
    public TokenException(String message) {
        super(message);
    }
}
