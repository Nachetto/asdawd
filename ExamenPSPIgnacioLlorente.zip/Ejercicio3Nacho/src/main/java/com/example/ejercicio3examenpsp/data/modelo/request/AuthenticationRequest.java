package com.example.ejercicio3examenpsp.data.modelo.request;


public record AuthenticationRequest(String username, String password) {

}
