package com.example.ejercicio3examenpsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio3ExamenPspApplicationTests {

    @Test
    void contextLoads() {
    }

}
