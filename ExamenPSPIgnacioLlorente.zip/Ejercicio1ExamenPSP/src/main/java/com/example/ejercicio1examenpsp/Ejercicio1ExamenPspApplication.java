package com.example.ejercicio1examenpsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio1ExamenPspApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio1ExamenPspApplication.class, args);
	}

}
